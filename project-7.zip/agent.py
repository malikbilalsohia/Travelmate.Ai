from langchain_ollama import ChatOllama
from langchain.agents import  AgentExecutor
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from config import OLLAMA_BASE_URL, OLLAMA_MODEL
from tools import (
    calculate_budget,
    calculate_available_time,
    generate_packing_list,
)


def create_travel_agent():
    llm = ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=0,
    )

    tools = [
        calculate_budget,
        calculate_available_time,
        generate_packing_list,
    ]

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """
You are TravelMate AI, an intelligent travel planning assistant.

Your job is to help users create practical trip plans.

You have access to tools for:
- calculating travel budgets
- calculating available time
- creating packing lists

Use the appropriate tool when it is useful.

Do not invent tool results.
Keep your answers clear and practical.
""",
            ),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]
    )

    agent = create_tool_calling_agent(
        llm,
        tools,
        prompt,
    )

    return AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
    )


def run_travel_agent(user_request):
    executor = create_travel_agent()

    result = executor.invoke(
        {
            "input": user_request
        }
    )

    return result["output"]


if __name__ == "__main__":
    print("TravelMate AI - Tool Calling Test")
    print("-" * 40)

    request = """
    I am planning a 3-day family trip to Islamabad.
    My total budget is Rs. 50,000.
    Calculate a suitable budget breakdown and give me a packing list.
    """

    try:
        response = run_travel_agent(request)

        print("\nFinal TravelMate Response:")
        print(response)

    except Exception as error:
        print("\nError:")
        print(error)