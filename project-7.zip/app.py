import html
from datetime import date, timedelta

import streamlit as st


# API-free sample flight catalog for the TravelMate demo.
# These fares are illustrative only and are not live airline prices.
PAKISTAN_CITIES = {
    "Lahore (LHE)": "LHE",
    "Islamabad (ISB)": "ISB",
    "Karachi (KHI)": "KHI",
    "Peshawar (PEW)": "PEW",
    "Quetta (UET)": "UET",
    "Multan (MUX)": "MUX",
    "Faisalabad (LYP)": "LYP",
    "Skardu (KDU)": "KDU",
    "Gilgit (GIL)": "GIL",
    "Muzzaffarabad (MFG)": "MFG",
}

DEMO_AIRLINES = (
    ("PIA", "PK", "#31c48d"),
    ("Airblue", "PA", "#4fc3ff"),
    ("Serene Air", "ER", "#f5b942"),
    ("Fly Jinnah", "9P", "#ff6b6b"),
)


def get_demo_flights(origin: str, destination: str, travelers: int, round_trip: bool) -> list[dict]:
    """Return predictable sample flights without an external API."""
    city_names = list(PAKISTAN_CITIES)
    origin_index = city_names.index(origin)
    destination_index = city_names.index(destination)
    city_gap = abs(origin_index - destination_index)
    one_way_base = 10500 + city_gap * 1750
    if "Skardu" in destination or "Gilgit" in destination:
        one_way_base += 6500
    if "Karachi" in origin or "Karachi" in destination:
        one_way_base += 2500

    fare_multiplier = 1.82 if round_trip else 1.0
    route_total = one_way_base * fare_multiplier * travelers
    schedules = (("06:20", "08:05", "1h 45m"), ("11:10", "13:00", "1h 50m"), ("18:40", "20:35", "1h 55m"))
    flights = []
    for index, (airline, code, accent) in enumerate(DEMO_AIRLINES[:3]):
        departure, arrival, duration = schedules[index]
        fare = route_total * (1 + index * 0.09)
        flights.append({
            "airline": airline,
            "flight_number": f"{code}-{240 + city_gap * 3 + index}",
            "accent": accent,
            "departure": departure,
            "arrival": arrival,
            "duration": duration,
            "stops": "Non-stop",
            "fare": fare,
            "per_passenger": fare / travelers,
            "baggage": "20 kg checked + 7 kg cabin",
        })
    return flights

from database import initialize_database
from auth import create_user, login_user
from profile import save_profile, get_profile
from dashboard import get_dashboard_data
from trip_manager import save_trip, get_user_trips, delete_trip
from agent import run_travel_agent
from tickets import render_ticket_page


# ==================================================
# DATABASE
# ==================================================

initialize_database()


# ==================================================
# PAGE CONFIG
# ==================================================

st.set_page_config(
    page_title="TravelMate AI",
    page_icon="✈️",
    layout="wide",
)


# ==================================================
# CUSTOM CSS
# ==================================================

st.markdown(
    """
    <style>
    :root {
        --navy-950: #061326;
        --navy-900: #0b1d35;
        --navy-800: #112b4a;
        --panel: #122b49;
        --panel-strong: #18395d;
        --blue-500: #4fc3ff;
        --blue-300: #c2ebff;
        --white: #ffffff;
        --muted: #e1edf7;
        --border: #7298b8;
    }

    html, body, [class*="css"], .stApp,
    [data-testid="stAppViewContainer"], [data-testid="stAppViewBlockContainer"] {
        color: #ffffff !important;
    }
    .stApp {
        background: linear-gradient(135deg, var(--navy-950) 0%, #0c203b 55%, #071426 100%) !important;
    }
    [data-testid="stHeader"] { background: rgba(6, 19, 38, 0.96) !important; }
    [data-testid="stSidebar"] { background: #091a30 !important; border-right: 1px solid var(--border) !important; }
    [data-testid="stSidebar"], [data-testid="stSidebar"] * { color: #ffffff !important; }

    .stApp h1, .stApp h2, .stApp h3, .stApp h4,
    .stApp p, .stApp label, .stApp span,
    .stApp .stMarkdown, .stApp .stMarkdown p,
    .stApp .stMarkdown li, .stApp .stMarkdown strong,
    .stApp [data-testid="stWidgetLabel"],
    .stApp [data-testid="stWidgetLabel"] p,
    .stApp [data-testid="stWidgetLabel"] label {
        color: #ffffff !important;
    }
    .main-title { font-size: 48px; font-weight: 850; text-align: center; margin-bottom: 5px; color: #ffffff !important; text-shadow: 0 2px 12px rgba(0,0,0,.35); }
    .subtitle { text-align: center; font-size: 18px; color: var(--muted) !important; margin-bottom: 30px; }
    .card { padding: 25px; border-radius: 20px; background: linear-gradient(145deg, var(--panel-strong), var(--panel)); border: 1px solid var(--border); box-shadow: 0 12px 30px rgba(0,0,0,.28); margin-bottom: 20px; }
    .login-heading { font-size: 26px; font-weight: 800; margin-bottom: 20px; color: #ffffff !important; }
    .field-label { font-size: 16px; font-weight: 700; margin-top: 12px; margin-bottom: 5px; color: #ffffff !important; }
    .stat { text-align: center; padding: 20px; border-radius: 18px; background: linear-gradient(160deg, #173758, #102744); border: 1px solid var(--border); box-shadow: 0 10px 24px rgba(0,0,0,.22); }
    .stat-number { font-size: 32px; font-weight: 850; color: #ffffff !important; }
    .stat-label { color: #f0f7fc !important; font-weight: 700; }
    .stTextInput input, .stNumberInput input, textarea,
    .stDateInput input, input, select {
        color: #ffffff !important; -webkit-text-fill-color: #ffffff !important;
        background: #102541 !important; border: 1px solid #8cafc8 !important;
    }
    .stTextInput input::placeholder, .stNumberInput input::placeholder, textarea::placeholder { color: #c7d9e8 !important; opacity: 1 !important; }
    div[data-baseweb="select"] > div { background: #102541 !important; border-color: #8cafc8 !important; }
    div[data-baseweb="select"] *, [role="option"], [role="listbox"] * { color: #ffffff !important; }
    .stTabs [data-baseweb="tab"], .stTabs [data-baseweb="tab"] p { color: #ffffff !important; font-weight: 750 !important; }
    .stTabs [aria-selected="true"] { color: #ffffff !important; border-bottom-color: var(--blue-500) !important; }
    .stButton > button, .stFormSubmitButton > button { color: #061526 !important; -webkit-text-fill-color: #061526 !important; background: linear-gradient(90deg, #87ddff, #45bfff) !important; border: none !important; border-radius: 12px !important; font-weight: 850 !important; min-height: 2.8rem; }
    .stButton > button:hover, .stFormSubmitButton > button:hover { background: #ffffff !important; color: #061526 !important; -webkit-text-fill-color: #061526 !important; }
    [data-testid="stAlert"], [data-testid="stAlert"] * { color: #ffffff !important; }
    .ai-plan-panel { color: #ffffff !important; background: #0d213b !important; border: 1px solid #7298b8 !important; border-left: 5px solid var(--blue-500) !important; border-radius: 16px !important; padding: 1.4rem 1.6rem !important; line-height: 1.75 !important; box-shadow: 0 12px 28px rgba(0,0,0,.24) !important; }
    .ai-plan-panel * { color: #ffffff !important; }
    .flight-card { background: linear-gradient(145deg, #163a5f, #0d2340) !important; border: 1px solid #7298b8 !important; border-radius: 18px !important; padding: 1.25rem !important; margin: .7rem 0 !important; box-shadow: 0 10px 25px rgba(0,0,0,.22) !important; }
    .flight-airline { color: #ffffff !important; font-size: 1.2rem !important; font-weight: 850 !important; }
    .flight-number, .flight-meta { color: #d9eaf7 !important; font-size: .88rem !important; }
    .flight-time { color: #ffffff !important; font-size: 1.25rem !important; font-weight: 850 !important; }
    .flight-route { color: #bde6ff !important; font-size: .85rem !important; }
    .flight-fare { color: #ffffff !important; font-size: 1.35rem !important; font-weight: 900 !important; }
    .flight-note { color: #dceaf6 !important; font-size: .85rem !important; }
    </style>
    """,
    unsafe_allow_html=True,
)


# ==================================================
# SESSION STATE
# ==================================================

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "user" not in st.session_state:
    st.session_state.user = None

if "generated_trip" not in st.session_state:
    st.session_state.generated_trip = None


# ==================================================
# LOGIN / SIGNUP
# ==================================================

if not st.session_state.logged_in:

    st.markdown(
        '<div class="main-title">✈️ TravelMate AI</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="subtitle">'
        "Your Intelligent Agentic Travel Assistant"
        "</div>",
        unsafe_allow_html=True,
    )

    tab_login, tab_signup = st.tabs(
        ["🔐 Login", "📝 Create Account"]
    )


    # ==================================================
    # LOGIN
    # ==================================================

    with tab_login:

        st.markdown(
            '<div class="card">',
            unsafe_allow_html=True,
        )

        st.markdown(
            '<div class="login-heading">🔐 Welcome Back</div>',
            unsafe_allow_html=True,
        )

        # USERNAME / EMAIL

        st.markdown(
            '<div class="field-label">👤 Username or Email</div>',
            unsafe_allow_html=True,
        )

        login_name = st.text_input(
            "Username or Email",
            placeholder="Enter your username or email",
            key="login_name",
            label_visibility="collapsed",
        )

        # PASSWORD

        st.markdown(
            '<div class="field-label">🔒 Password</div>',
            unsafe_allow_html=True,
        )

        login_password = st.text_input(
            "Password",
            placeholder="Enter your password",
            type="password",
            key="login_password",
            label_visibility="collapsed",
        )

        st.write("")

        if st.button(
            "🚀 Login to TravelMate",
            use_container_width=True,
        ):

            if not login_name or not login_password:

                st.warning(
                    "Please enter your username/email and password."
                )

            else:

                user = login_user(
                    login_name,
                    login_password,
                )

                if user:

                    st.session_state.logged_in = True
                    st.session_state.user = user

                    st.success(
                        "Login successful!"
                    )

                    st.rerun()

                else:

                    st.error(
                        "Invalid username/email or password."
                    )

        st.markdown("</div>", unsafe_allow_html=True)


    # ==================================================
    # SIGNUP
    # ==================================================

    with tab_signup:

        st.markdown(
            '<div class="card">',
            unsafe_allow_html=True,
        )

        st.markdown(
            '<div class="login-heading">✨ Create Your Account</div>',
            unsafe_allow_html=True,
        )

        # USERNAME

        st.markdown(
            '<div class="field-label">👤 Username</div>',
            unsafe_allow_html=True,
        )

        signup_username = st.text_input(
            "Username",
            placeholder="Choose a username",
            key="signup_username",
            label_visibility="collapsed",
        )

        # EMAIL

        st.markdown(
            '<div class="field-label">📧 Email Address</div>',
            unsafe_allow_html=True,
        )

        signup_email = st.text_input(
            "Email Address",
            placeholder="Enter your email address",
            key="signup_email",
            label_visibility="collapsed",
        )

        # PASSWORD

        st.markdown(
            '<div class="field-label">🔒 Password</div>',
            unsafe_allow_html=True,
        )

        signup_password = st.text_input(
            "Password",
            placeholder="Create a password (minimum 6 characters)",
            type="password",
            key="signup_password",
            label_visibility="collapsed",
        )

        st.write("")

        if st.button(
            "✨ Create My TravelMate Account",
            use_container_width=True,
        ):

            if (
                not signup_username
                or not signup_email
                or not signup_password
            ):

                st.warning(
                    "Please complete all fields."
                )

            else:

                success, message = create_user(
                    signup_username,
                    signup_email,
                    signup_password,
                )

                if success:

                    st.success(message)

                    st.info(
                        "Your account is ready. "
                        "Open the Login tab and sign in."
                    )

                else:

                    st.error(message)

        st.markdown("</div>", unsafe_allow_html=True)


    st.stop()


# ==================================================
# LOGGED-IN USER
# ==================================================

user = st.session_state.user
user_id = user["id"]


# ==================================================
# SIDEBAR
# ==================================================

with st.sidebar:

    st.markdown("## ✈️ TravelMate AI")

    st.write(
        f"👋 Welcome, **{user['username']}**"
    )

    st.divider()

    page = st.radio(
        "Navigation",
        [
            "📊 Dashboard",
            "🤖 AI Trip Planner",
            "🎟️ Flight Tickets",
            "👤 My Profile",
            "💾 My Trips",
        ],
    )

    st.divider()

    if st.button(
        "🚪 Logout",
        use_container_width=True,
    ):

        st.session_state.logged_in = False
        st.session_state.user = None

        st.rerun()


# ==================================================
# DASHBOARD
# ==================================================

if page == "📊 Dashboard":

    st.markdown(
        '<div class="main-title">Travel Dashboard</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="subtitle">'
        "Your personal travel command center"
        "</div>",
        unsafe_allow_html=True,
    )

    data = get_dashboard_data(user_id)

    col1, col2, col3 = st.columns(3)

    with col1:

        st.markdown(
            f"""
            <div class="stat">
                <div class="stat-number">
                    {data["total_trips"]}
                </div>
                <div class="stat-label">
                    🗺️ Saved Trips
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col2:

        st.markdown(
            f"""
            <div class="stat">
                <div class="stat-number">
                    Rs. {data["total_budget"]:,.0f}
                </div>
                <div class="stat-label">
                    💰 Planned Budget
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col3:

        st.markdown(
            f"""
            <div class="stat">
                <div class="stat-number">
                    Rs. {data["average_budget"]:,.0f}
                </div>
                <div class="stat-label">
                    📊 Average Budget
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.divider()

    st.markdown("## 🧭 Quick Start")

    if st.button(
        "✨ Create a New AI Trip Plan",
        use_container_width=True,
    ):

        st.info(
            "Select '🤖 AI Trip Planner' from the sidebar."
        )

    st.markdown("## 🗺️ Recent Trips")

    if data["recent_trips"]:

        for trip in data["recent_trips"]:

            st.markdown(
                f"""
                <div class="card">
                    <h3>✈️ {trip["destination"]}</h3>
                    <p>
                    📅 {trip["days"]} Days
                    &nbsp;&nbsp;|&nbsp;&nbsp;
                    💰 Rs. {trip["budget"]:,.0f}
                    &nbsp;&nbsp;|&nbsp;&nbsp;
                    👥 {trip["travelers"]} Travelers
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )

    else:

        st.info(
            "No trips saved yet. Create your first AI trip!"
        )


# ==================================================
# AI TRIP PLANNER
# ==================================================

elif page == "🤖 AI Trip Planner":

    st.markdown(
        '<div class="main-title">🤖 AI Trip Planner</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="subtitle">'
        "Let TravelMate AI design your journey"
        "</div>",
        unsafe_allow_html=True,
    )

    col1, col2 = st.columns(2)

    with col1:

        destination = st.text_input(
            "📍 Destination",
            placeholder="Example: Islamabad",
        )

        starting_location = st.text_input(
            "🚗 Starting Location",
            placeholder="Example: Lahore",
        )

        days = st.number_input(
            "📅 Trip Duration (Days)",
            min_value=1,
            max_value=30,
            value=3,
        )

    with col2:

        budget = st.number_input(
            "💰 Total Budget (Rs.)",
            min_value=1000,
            value=50000,
            step=1000,
        )

        travelers = st.number_input(
            "👥 Number of Travelers",
            min_value=1,
            max_value=50,
            value=2,
        )

        interests = st.text_input(
            "❤️ Travel Interests",
            placeholder="Nature, Food, Photography",
        )

    st.divider()

    if st.button(
        "🚀 Generate Intelligent Travel Plan",
        type="primary",
        use_container_width=True,
    ):

        if not destination.strip() or not starting_location.strip():
            st.warning("Please enter destination and starting location.")
        else:
            request = f"""
Create a practical travel plan.

Destination: {destination}
Starting Location: {starting_location}
Duration: {days} days
Budget: Rs. {budget}
Travelers: {travelers}
Interests: {interests}

Provide:
1. Trip overview
2. Daily itinerary
3. Budget suggestions
4. Activities
5. Packing suggestions
6. Travel tips
"""

            with st.spinner("🤖 TravelMate agents are planning your trip..."):
                try:
                    response = run_travel_agent(request)
                    st.session_state.generated_trip = {
                        "destination": destination.strip(),
                        "starting_location": starting_location.strip(),
                        "days": int(days),
                        "budget": float(budget),
                        "travelers": int(travelers),
                        "interests": interests.strip(),
                        "trip_plan": response,
                    }
                    st.rerun()
                except Exception as error:
                    st.session_state.generated_trip = None
                    st.error("TravelMate encountered an error while creating the plan.")
                    st.code(str(error))

    generated_trip = st.session_state.get("generated_trip")
    if generated_trip:
        st.success("🎉 Travel plan generated! Review it and save it below.")
        st.markdown("## 🗺️ Your AI Travel Plan")
        readable_plan = html.escape(str(generated_trip["trip_plan"])).replace("\n", "<br>")
        st.markdown(
            f'<div class="ai-plan-panel">{readable_plan}</div>',
            unsafe_allow_html=True,
        )

        if st.button("💾 Save This Trip", type="primary", key="save_generated_trip", use_container_width=True):
            try:
                saved_id = save_trip(
                    user_id=user_id,
                    destination=generated_trip["destination"],
                    starting_location=generated_trip["starting_location"],
                    days=generated_trip["days"],
                    budget=generated_trip["budget"],
                    travelers=generated_trip["travelers"],
                    interests=generated_trip["interests"],
                    trip_plan=generated_trip["trip_plan"],
                )
                st.session_state.generated_trip = None
                st.success(f"Trip saved successfully! Trip ID: {saved_id}")
                st.rerun()
            except Exception as error:
                st.error("The trip could not be saved. Please try again.")
                st.code(str(error))


# ==================================================
# FLIGHT TICKETS
# ==================================================

elif page == "🎟️ Flight Tickets":
    render_ticket_page()

elif False:

    st.markdown('<div class="main-title">🎟️ Flight Tickets</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtitle">Search sample domestic flights across Pakistan</div>', unsafe_allow_html=True)
    st.info("Demo mode: fares are sample prices for your final-year project and are not live airline rates.")

    with st.form("flight_search_form"):
        search_columns = st.columns(2)
        with search_columns[0]:
            origin = st.selectbox("🛫 From", list(PAKISTAN_CITIES), index=0)
        with search_columns[1]:
            destination = st.selectbox("🛬 To", list(PAKISTAN_CITIES), index=1)

        date_columns = st.columns(3)
        with date_columns[0]:
            departure_date = st.date_input("📅 Departure", value=date.today() + timedelta(days=1), min_value=date.today())
        with date_columns[1]:
            return_date = st.date_input("📅 Return", value=date.today() + timedelta(days=4), min_value=date.today())
        with date_columns[2]:
            travelers = st.number_input("👥 Travelers", min_value=1, max_value=9, value=1, step=1)

        trip_type = st.radio("Trip type", ["One way", "Round trip"], horizontal=True)
        search_flights = st.form_submit_button("🔎 Search Flights", type="primary", use_container_width=True)

    if search_flights:
        if origin == destination:
            st.error("Please select two different cities.")
        elif trip_type == "Round trip" and return_date < departure_date:
            st.error("Return date must be after the departure date.")
        else:
            st.session_state.flight_search = {
                "origin": origin,
                "destination": destination,
                "departure_date": departure_date.isoformat(),
                "return_date": return_date.isoformat(),
                "travelers": int(travelers),
                "round_trip": trip_type == "Round trip",
            }
            st.session_state.selected_flight = None
            st.rerun()

    flight_search = st.session_state.get("flight_search")
    if flight_search:
        flights = get_demo_flights(
            flight_search["origin"],
            flight_search["destination"],
            flight_search["travelers"],
            flight_search["round_trip"],
        )
        route_type = "Round trip" if flight_search["round_trip"] else "One way"
        st.markdown(
            f"### {flight_search['origin']} → {flight_search['destination']}"
        )
        st.markdown(
            f'<p class="flight-note">{flight_search["departure_date"]} · {route_type} · {flight_search["travelers"]} traveler(s) · {len(flights)} sample flights found</p>',
            unsafe_allow_html=True,
        )

        for index, flight in enumerate(flights):
            origin_code = PAKISTAN_CITIES[flight_search["origin"]]
            destination_code = PAKISTAN_CITIES[flight_search["destination"]]
            st.markdown(
                f"""
                <div class="flight-card">
                    <div class="flight-airline">{flight['airline']} <span class="flight-number">{flight['flight_number']}</span></div>
                    <div class="flight-meta" style="margin-top:.55rem;">{flight['baggage']} · {flight['stops']}</div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem;">
                        <div><div class="flight-time">{flight['departure']} — {flight['arrival']}</div><div class="flight-route">{origin_code} → {destination_code} · {flight['duration']}</div></div>
                        <div style="text-align:right;"><div class="flight-fare">Rs. {flight['fare']:,.0f}</div><div class="flight-meta">total for {flight_search['travelers']} traveler(s)</div></div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            if st.button("Select Flight", key=f"select_flight_{index}", use_container_width=True):
                selected_flight = dict(flight)
                selected_flight.update(flight_search)
                st.session_state.selected_flight = selected_flight
                st.rerun()

        selected_flight = st.session_state.get("selected_flight")
        if selected_flight:
            st.divider()
            st.markdown("## ✅ Demo Booking Details")
            st.markdown(
                f'<p class="flight-note">Selected: <strong style="color:#ffffff;">{selected_flight["airline"]} {selected_flight["flight_number"]}</strong> · {selected_flight["origin"]} → {selected_flight["destination"]} · Rs. {selected_flight["fare"]:,.0f}</p>',
                unsafe_allow_html=True,
            )
            with st.form("demo_booking_form"):
                passenger_name = st.text_input("Passenger name", placeholder="Enter passenger name")
                passenger_email = st.text_input("Email for demo confirmation", placeholder="name@example.com")
                confirm_booking = st.form_submit_button("🎫 Confirm Demo Booking", type="primary", use_container_width=True)
            if confirm_booking:
                if not passenger_name.strip() or not passenger_email.strip():
                    st.warning("Please enter passenger name and email.")
                else:
                    reference = f"TM-{selected_flight['flight_number'].replace('-', '')}-{selected_flight['travelers']}"
                    st.success(f"Demo booking confirmed. Reference: {reference}. No payment was processed.")


# ==================================================
# PROFILE
# ==================================================

elif page == "👤 My Profile":

    st.markdown(
        '<div class="main-title">👤 Traveler Profile</div>',
        unsafe_allow_html=True,
    )

    profile = get_profile(user_id)

    if profile:

        default_name = profile["full_name"] or ""
        default_age = profile["age"] or 18
        default_location = profile["location"] or ""
        default_style = profile["travel_style"] or ""
        default_interests = profile["interests"] or ""
        default_budget = profile["preferred_budget"] or 50000

    else:

        default_name = ""
        default_age = 18
        default_location = ""
        default_style = ""
        default_interests = ""
        default_budget = 50000

    st.markdown("### 👤 Personal Information")

    full_name = st.text_input(
        "Full Name",
        value=default_name,
        placeholder="Enter your full name",
    )

    age = st.number_input(
        "Age",
        min_value=1,
        max_value=100,
        value=int(default_age),
    )

    location = st.text_input(
        "Current Location",
        value=default_location,
        placeholder="Example: Layyah, Pakistan",
    )

    st.markdown("### 🧭 Travel Preferences")

    travel_style = st.selectbox(
        "Preferred Travel Style",
        [
            "Adventure",
            "Relaxation",
            "Family",
            "Cultural",
            "Nature",
            "Photography",
        ],
        index=(
            [
                "Adventure",
                "Relaxation",
                "Family",
                "Cultural",
                "Nature",
                "Photography",
            ].index(default_style)
            if default_style in [
                "Adventure",
                "Relaxation",
                "Family",
                "Cultural",
                "Nature",
                "Photography",
            ]
            else 0
        ),
    )

    interests = st.text_input(
        "Travel Interests",
        value=default_interests,
        placeholder="Nature, Food, Photography",
    )

    preferred_budget = st.number_input(
        "Preferred Travel Budget (Rs.)",
        min_value=1000.0,
        value=float(default_budget),
        step=1000.0,
    )

    if st.button(
        "💾 Save My Profile",
        type="primary",
        use_container_width=True,
    ):

        save_profile(
            user_id=user_id,
            full_name=full_name,
            age=age,
            location=location,
            travel_style=travel_style,
            interests=interests,
            preferred_budget=preferred_budget,
        )

        st.success(
            "Profile saved successfully!"
        )


# ==================================================
# MY TRIPS
# ==================================================

elif page == "💾 My Trips":

    st.markdown(
        '<div class="main-title">💾 My Trips</div>',
        unsafe_allow_html=True,
    )

    st.markdown(
        '<div class="subtitle">'
        "Your saved travel plans"
        "</div>",
        unsafe_allow_html=True,
    )

    trips = get_user_trips(user_id)

    if not trips:

        st.info(
            "You haven't saved any trips yet."
        )

    else:

        for trip in trips:

            with st.expander(
                f"✈️ {trip['destination']} — "
                f"{trip['days']} Days"
            ):

                st.write(
                    f"**🚗 Starting Location:** "
                    f"{trip['starting_location']}"
                )

                st.write(
                    f"**💰 Budget:** "
                    f"Rs. {trip['budget']:,.0f}"
                )

                st.write(
                    f"**👥 Travelers:** "
                    f"{trip['travelers']}"
                )

                st.write(
                    f"**❤️ Interests:** "
                    f"{trip['interests']}"
                )

                st.divider()

                st.markdown(
                    "### 🗺️ Saved Travel Plan"
                )

                st.write(
                    trip["trip_plan"]
                )

                if st.button(
                    "🗑️ Delete This Trip",
                    key=f"delete_{trip['id']}",
                ):

                    delete_trip(
                        trip["id"],
                        user_id,
                    )

                    st.success(
                        "Trip deleted successfully."
                    )

                    st.rerun()