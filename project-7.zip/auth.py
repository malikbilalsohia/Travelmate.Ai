import hashlib

from database import get_connection


def hash_password(password: str) -> str:
    """Convert a password into a secure hash."""

    return hashlib.sha256(
        password.encode("utf-8")
    ).hexdigest()


def create_user(
    username: str,
    email: str,
    password: str,
):
    """Create a new TravelMate user."""

    username = username.strip()
    email = email.strip().lower()

    if not username or not email or not password:
        return False, "All fields are required."

    if len(password) < 6:
        return False, "Password must contain at least 6 characters."

    connection = get_connection()
    cursor = connection.cursor()

    try:
        cursor.execute(
            """
            INSERT INTO users
            (username, email, password)
            VALUES (?, ?, ?)
            """,
            (
                username,
                email,
                hash_password(password),
            ),
        )

        connection.commit()

        return True, "Account created successfully."

    except Exception as error:

        if "UNIQUE constraint failed" in str(error):

            return False, (
                "Username or email already exists."
            )

        return False, str(error)

    finally:
        connection.close()


def login_user(
    username_or_email: str,
    password: str,
):
    """Authenticate an existing user."""

    username_or_email = username_or_email.strip()

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM users
        WHERE username = ?
           OR email = ?
        """,
        (
            username_or_email,
            username_or_email.lower(),
        ),
    )

    user = cursor.fetchone()

    connection.close()

    if user is None:
        return None

    password_hash = hash_password(password)

    if user["password"] != password_hash:
        return None

    return dict(user)


def get_user_by_id(user_id: int):
    """Get a user using their database ID."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT id, username, email, created_at
        FROM users
        WHERE id = ?
        """,
        (user_id,),
    )

    user = cursor.fetchone()

    connection.close()

    if user is None:
        return None

    return dict(user)


if __name__ == "__main__":

    from database import initialize_database

    initialize_database()

    print("Testing TravelMate authentication...")
    print("-" * 40)

    success, message = create_user(
        "test_user",
        "test@travelmate.com",
        "123456",
    )

    print("Signup:", message)

    user = login_user(
        "test_user",
        "123456",
    )

    if user:
        print("Login: Successful")
        print("Username:", user["username"])
        print("Email:", user["email"])
    else:
        print("Login: Failed")