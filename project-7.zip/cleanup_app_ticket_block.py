from pathlib import Path

path = Path('/home/ubuntu/upload/app.py')
text = path.read_text(encoding='utf-8')
start_marker = 'elif False:\n'
end_marker = '# ==================================================\n# PROFILE'
start = text.find(start_marker)
if start == -1:
    raise SystemExit('obsolete block not found')
end = text.find(end_marker, start)
if end == -1:
    raise SystemExit('profile marker not found')
path.write_text(text[:start] + text[end:], encoding='utf-8')
print('removed obsolete inline ticket block')
