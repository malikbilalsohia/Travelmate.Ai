"""
TravelMate dashboard.

Run with:
    streamlit run dashboard.py

The existing data functions from trip_manager.py and profile.py are preserved.
When a database save helper is available in trip_manager.py, it is used first.
Otherwise, submitted trips are stored in .travelmate_trips.json so they remain
available after restarting the app.
"""

from __future__ import annotations

import inspect
import json
from datetime import datetime
from pathlib import Path
from typing import Any

import streamlit as st

from profile import get_profile
from trip_manager import get_user_trips


LOCAL_STORE = Path(__file__).with_name(".travelmate_trips.json")


# ----------------------------- Data layer -----------------------------

def _read_local_trips() -> list[dict[str, Any]]:
    """Read the local fallback store without breaking the dashboard on bad data."""
    if not LOCAL_STORE.exists():
        return []

    try:
        content = json.loads(LOCAL_STORE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

    return content if isinstance(content, list) else []


def _write_local_trips(trips: list[dict[str, Any]]) -> None:
    """Write trips atomically so a partial write cannot destroy saved data."""
    temporary_file = LOCAL_STORE.with_suffix(".tmp")
    temporary_file.write_text(
        json.dumps(trips, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    temporary_file.replace(LOCAL_STORE)


def _normalise_trip(trip: dict[str, Any]) -> dict[str, Any]:
    """Return a complete, consistent trip shape for every dashboard view."""
    return {
        "id": trip.get("id"),
        "user_id": trip.get("user_id"),
        "destination": str(trip.get("destination", "Unknown destination")),
        "starting_location": str(trip.get("starting_location", "Not set") or "Not set"),
        "days": int(trip.get("days", 0) or 0),
        "budget": float(trip.get("budget", 0) or 0),
        "travelers": int(trip.get("travelers", 1) or 1),
        "interests": str(trip.get("interests", "") or ""),
        "trip_plan": str(trip.get("trip_plan", "") or ""),
        "created_at": trip.get("created_at") or datetime.now().isoformat(timespec="seconds"),
    }


def _call_project_save_helper(user_id: int, trip: dict[str, Any]) -> bool:
    """Use an existing project save function when one is exposed by trip_manager.

    The dashboard supports common helper names without requiring changes to the
    rest of the project. If no helper exists, the caller uses the local fallback.
    """
    try:
        import trip_manager
    except ImportError:
        return False

    helper_names = ("save_trip", "create_trip", "add_trip")
    helper = next(
        (getattr(trip_manager, name, None) for name in helper_names if callable(getattr(trip_manager, name, None))),
        None,
    )
    if helper is None:
        return False

    values = {
        "user_id": user_id,
        "destination": trip["destination"],
        "starting_location": trip.get("starting_location", "Not set"),
        "days": trip["days"],
        "budget": trip["budget"],
        "travelers": trip.get("travelers", 1),
        "interests": trip.get("interests", ""),
        "trip_plan": trip.get("trip_plan", ""),
    }

    try:
        parameters = inspect.signature(helper).parameters
        keyword_values = {key: value for key, value in values.items() if key in parameters}
        helper(**keyword_values)
        return True
    except (TypeError, ValueError, OSError):
        return False


def save_trip(user_id: int, destination: str, days: int, budget: float) -> None:
    """Persist a trip through the project data layer or a durable local fallback."""
    trip = _normalise_trip(
        {
            "user_id": user_id,
            "destination": destination.strip(),
            "days": days,
            "budget": budget,
        }
    )

    if _call_project_save_helper(user_id, trip):
        return

    existing = _read_local_trips()
    existing.insert(0, trip)
    _write_local_trips(existing)


def _get_saved_trips(user_id: int) -> list[dict[str, Any]]:
    """Load project trips and include local fallback records for this user."""
    try:
        project_trips = get_user_trips(user_id) or []
    except (KeyError, TypeError, OSError):
        project_trips = []

    project_trips = [_normalise_trip(trip) for trip in project_trips if isinstance(trip, dict)]
    local_trips = [
        _normalise_trip(trip)
        for trip in _read_local_trips()
        if isinstance(trip, dict) and (trip.get("user_id") in (None, user_id))
    ]

    # Avoid duplicate display when the project save helper also mirrors locally.
    combined = project_trips[:]
    known = {
        (trip["destination"], trip["days"], trip["budget"])
        for trip in combined
    }
    for trip in local_trips:
        key = (trip["destination"], trip["days"], trip["budget"])
        if key not in known:
            combined.append(trip)
            known.add(key)

    return combined


def get_dashboard_data(user_id: int) -> dict[str, Any]:
    """Prepare dashboard information for a logged-in traveler."""
    try:
        profile = get_profile(user_id)
    except (KeyError, TypeError, OSError):
        profile = None

    trips = _get_saved_trips(user_id)
    total_trips = len(trips)
    total_budget = sum(float(trip.get("budget", 0) or 0) for trip in trips)
    average_budget = total_budget / total_trips if total_trips else 0

    return {
        "profile": profile,
        "trips": trips,
        "recent_trips": trips[:5],
        "total_trips": total_trips,
        "total_budget": total_budget,
        "average_budget": average_budget,
    }


# ----------------------------- UI layer -----------------------------

def _apply_professional_theme() -> None:
    """Apply a high-contrast navy theme with deliberately bright text."""
    st.markdown(
        """
        <style>
        :root {
            --navy-950: #071426;
            --navy-900: #0b1b32;
            --navy-800: #112847;
            --blue-500: #42b8ff;
            --blue-300: #9edcff;
            --white: #ffffff;
            --muted: #d6e4f2;
            --line: #52718f;
        }

        .stApp {
            background: linear-gradient(135deg, var(--navy-950) 0%, #0c203b 55%, #071426 100%);
            color: var(--white);
        }

        [data-testid="stHeader"] { background: rgba(7, 20, 38, 0.92); }
        [data-testid="stSidebar"] { background: #09192e !important; border-right: 1px solid var(--line) !important; }
        [data-testid="stSidebar"] * { color: var(--white) !important; }

        .stApp h1, .stApp h2, .stApp h3, .stApp h4,
        .stApp p, .stApp label, .stApp span,
        .stApp .stMarkdown, .stApp .stMarkdown p,
        .stApp .stMarkdown li, .stApp [data-testid="stWidgetLabel"],
        .stApp [data-testid="stWidgetLabel"] p { color: #ffffff !important; }
        h1 { letter-spacing: -0.03em; font-weight: 800; color: #ffffff !important; }
        h2, h3 { font-weight: 750; color: #ffffff !important; }
        .muted { color: var(--muted) !important; }
        .eyebrow { color: var(--blue-300) !important; text-transform: uppercase; letter-spacing: 0.14em; font-size: 0.75rem; font-weight: 800; }

        .hero {
            padding: 2rem 2.2rem;
            border: 1px solid #6283a2;
            border-radius: 24px;
            background: linear-gradient(135deg, #142e50 0%, #0c1e39 100%);
            box-shadow: 0 18px 50px rgba(0,0,0,.25);
            margin-bottom: 1.5rem;
        }

        .metric-card {
            min-height: 145px;
            padding: 1.25rem 1.3rem;
            border: 1px solid var(--line);
            border-radius: 18px;
            background: linear-gradient(160deg, #173453 0%, #102641 100%);
            box-shadow: 0 10px 28px rgba(0,0,0,.18);
        }
        .metric-icon { font-size: 1.55rem; }
        .metric-value { margin-top: .45rem; font-size: 2rem; font-weight: 850; color: #ffffff !important; }
        .metric-label { color: #e7f1fa !important; font-size: .95rem; font-weight: 650; }

        .trip-card {
            padding: 1rem 1.2rem;
            margin: .65rem 0;
            border: 1px solid #385b7b;
            border-left: 4px solid var(--blue-500);
            border-radius: 14px;
            background: rgba(18, 48, 82, .9);
        }
        .trip-title { color: #ffffff !important; font-weight: 800; font-size: 1.05rem; }
        .trip-meta { color: #d8eaf8 !important; font-size: .9rem; }

        .stTextInput input, .stNumberInput input, .stDateInput input, textarea, input {
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
            background: #102541 !important;
            border: 1px solid #8cafc8 !important;
        }
        .stTextInput input::placeholder, .stNumberInput input::placeholder { color: #b8cde0 !important; }
        div[data-baseweb="select"] > div { background: #102541 !important; border-color: #6c8eab !important; }
        div[data-baseweb="select"] * { color: #ffffff !important; }
        .stButton > button, .stFormSubmitButton > button {
            color: #061526 !important;
            background: linear-gradient(90deg, #7ed4ff, #42b8ff) !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 800 !important;
            min-height: 2.8rem;
        }
        .stButton > button:hover, .stFormSubmitButton > button:hover { background: #ffffff !important; }
        [data-testid="stForm"] { background: #0d213b; border: 1px solid #52718f; border-radius: 18px; padding: 1rem 1.2rem; }
        [data-testid="stAlert"] * { color: #ffffff !important; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _display_metric(icon: str, value: str, label: str) -> None:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-icon">{icon}</div>
            <div class="metric-value">{value}</div>
            <div class="metric-label">{label}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _display_trip(trip: dict[str, Any]) -> None:
    destination = trip.get("destination", "Unknown destination")
    days = int(trip.get("days", 0) or 0)
    budget = float(trip.get("budget", 0) or 0)
    st.markdown(
        f"""
        <div class="trip-card">
            <div class="trip-title">✈️ {destination}</div>
            <div class="trip-meta">{days} days&nbsp;&nbsp; • &nbsp;&nbsp;Rs. {budget:,.0f}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def run_streamlit_dashboard(user_id: int = 1) -> None:
    """Render the interactive dashboard."""
    st.set_page_config(
        page_title="TravelMate Dashboard",
        page_icon="✈️",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    _apply_professional_theme()

    data = get_dashboard_data(user_id)
    profile = data["profile"] or {}
    traveler_name = profile.get("full_name", "Traveler")
    location = profile.get("location", "Ready for your next adventure")

    st.markdown('<div class="eyebrow">TravelMate AI Planner</div>', unsafe_allow_html=True)
    st.markdown(f"# Welcome back, {traveler_name}")
    st.markdown(f'<p class="muted">{location} · Plan smarter, travel better.</p>', unsafe_allow_html=True)

    st.markdown(
        """
        <div class="hero">
            <div class="eyebrow">Your travel command center</div>
            <h2 style="margin-bottom:.35rem;">Turn your next idea into a memorable trip.</h2>
            <p class="muted" style="margin:0;">Create a plan, keep your trips organized, and track your travel budget in one place.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    metric_columns = st.columns(3, gap="large")
    with metric_columns[0]:
        _display_metric("🗺️", f"{data['total_trips']}", "Trips Planned")
    with metric_columns[1]:
        _display_metric("💰", f"Rs. {data['total_budget']:,.0f}", "Total Planned Budget")
    with metric_columns[2]:
        _display_metric("📊", f"Rs. {data['average_budget']:,.0f}", "Average Trip Budget")

    st.divider()
    left, right = st.columns([1.6, 1], gap="large")

    with left:
        st.markdown("## Quick Start")
        st.markdown('<p class="muted">Save a new trip below. It will remain available after restarting the app.</p>', unsafe_allow_html=True)
        with st.form("new_trip_form", clear_on_submit=True):
            destination = st.text_input("Destination", placeholder="e.g. Hunza Valley")
            form_columns = st.columns(2)
            with form_columns[0]:
                days = st.number_input("Number of days", min_value=1, max_value=365, value=3, step=1)
            with form_columns[1]:
                budget = st.number_input("Budget (Rs.)", min_value=0.0, value=50000.0, step=5000.0)
            submitted = st.form_submit_button("✨ Save New AI Trip", use_container_width=True)

        if submitted:
            if not destination.strip():
                st.error("Please enter a destination before saving.")
            else:
                try:
                    save_trip(user_id, destination, int(days), float(budget))
                    st.success(f"Trip to {destination.strip()} saved successfully.")
                    st.rerun()
                except (OSError, TypeError, ValueError) as error:
                    st.error(f"The trip could not be saved: {error}")

    with right:
        st.markdown("## Travel Profile")
        profile_items = (
            ("Traveler", profile.get("full_name", "Not completed")),
            ("Location", profile.get("location", "Not set")),
            ("Travel style", profile.get("travel_style", "Not set")),
        )
        for label, value in profile_items:
            st.markdown(
                f'<div class="trip-card"><div class="trip-meta">{label}</div><div class="trip-title">{value}</div></div>',
                unsafe_allow_html=True,
            )

    st.divider()
    st.markdown("## Recent Trips")
    recent_trips = data["recent_trips"]
    if not recent_trips:
        st.info("No trips saved yet. Create your first AI trip above.")
    else:
        trip_columns = st.columns(2, gap="medium")
        for index, trip in enumerate(recent_trips):
            with trip_columns[index % 2]:
                _display_trip(trip)


def print_dashboard(user_id: int) -> None:
    """Print dashboard information for command-line testing."""
    data = get_dashboard_data(user_id)
    print("\n" + "=" * 56)
    print("                 TRAVELMATE DASHBOARD")
    print("=" * 56)
    profile = data["profile"]
    if profile:
        print(f"Traveler: {profile.get('full_name', 'Traveler')}")
        print(f"Location: {profile.get('location', 'Not set')}")
        print(f"Travel Style: {profile.get('travel_style', 'Not set')}")
    else:
        print("Traveler profile not completed.")
    print(f"\nTotal Trips: {data['total_trips']}")
    print(f"Total Planned Budget: Rs. {data['total_budget']:,.0f}")
    print(f"Average Trip Budget: Rs. {data['average_budget']:,.0f}")
    print("\nRecent Trips")
    print("-" * 56)
    if not data["recent_trips"]:
        print("No trips saved yet.")
    else:
        for trip in data["recent_trips"]:
            print(f"✈️ {trip['destination']} | {trip['days']} days | Rs. {trip['budget']:,.0f}")
    print("=" * 56)


if __name__ == "__main__":
    run_streamlit_dashboard(user_id=1)
