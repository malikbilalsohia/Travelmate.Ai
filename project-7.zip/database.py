import sqlite3
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
DATABASE_FILE = BASE_DIR / "travelmate.db"


def get_connection():
    """Create a connection to the TravelMate database."""

    connection = sqlite3.connect(
        DATABASE_FILE,
        check_same_thread=False
    )

    connection.row_factory = sqlite3.Row

    return connection


def initialize_database():
    """Create all required database tables."""

    connection = get_connection()
    cursor = connection.cursor()

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Traveler profiles table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS traveler_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            full_name TEXT,
            age INTEGER,
            location TEXT,
            travel_style TEXT,
            interests TEXT,
            preferred_budget REAL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # Saved trips table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS trips (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            destination TEXT NOT NULL,
            starting_location TEXT,
            days INTEGER,
            budget REAL,
            travelers INTEGER,
            interests TEXT,
            trip_plan TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    connection.commit()
    connection.close()


if __name__ == "__main__":

    print("Initializing TravelMate database...")

    initialize_database()

    print("Database created successfully!")
    print(f"Database location: {DATABASE_FILE}")