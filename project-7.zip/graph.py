from typing import TypedDict

from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, START, END

from config import OLLAMA_BASE_URL, OLLAMA_MODEL


class TravelState(TypedDict):
    user_request: str
    response: str


llm = ChatOllama(
    model=OLLAMA_MODEL,
    base_url=OLLAMA_BASE_URL,
    temperature=0,
)


def travel_agent(state: TravelState):
    """Process the user's travel request."""

    prompt = f"""
You are TravelMate AI, an intelligent travel planning assistant.

Analyze the following travel request and provide a helpful response.

User Request:
{state["user_request"]}

Keep the response practical and easy to understand.
"""

    result = llm.invoke(prompt)

    return {
        "response": result.content
    }


def build_graph():
    """Build the TravelMate LangGraph workflow."""

    workflow = StateGraph(TravelState)

    workflow.add_node("travel_agent", travel_agent)

    workflow.add_edge(START, "travel_agent")
    workflow.add_edge("travel_agent", END)

    return workflow.compile()


if __name__ == "__main__":

    print("Starting TravelMate LangGraph...")
    print("-" * 40)

    graph = build_graph()

    result = graph.invoke(
        {
            "user_request": (
                "Plan a simple 2-day trip to Islamabad "
                "from Lahore for a budget of Rs. 30,000."
            ),
            "response": "",
        }
    )

    print("TravelMate Result:")
    print(result["response"])