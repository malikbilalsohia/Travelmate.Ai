from database import get_connection


def save_profile(
    user_id: int,
    full_name: str,
    age: int,
    location: str,
    travel_style: str,
    interests: str,
    preferred_budget: float,
):
    """Create or update a traveler profile."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        INSERT INTO traveler_profiles
        (
            user_id,
            full_name,
            age,
            location,
            travel_style,
            interests,
            preferred_budget
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)

        ON CONFLICT(user_id)
        DO UPDATE SET
            full_name = excluded.full_name,
            age = excluded.age,
            location = excluded.location,
            travel_style = excluded.travel_style,
            interests = excluded.interests,
            preferred_budget = excluded.preferred_budget
        """,
        (
            user_id,
            full_name,
            age,
            location,
            travel_style,
            interests,
            preferred_budget,
        ),
    )

    connection.commit()
    connection.close()

    return True


def get_profile(user_id: int):
    """Get the traveler profile of a user."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM traveler_profiles
        WHERE user_id = ?
        """,
        (user_id,),
    )

    profile = cursor.fetchone()

    connection.close()

    if profile is None:
        return None

    return dict(profile)


def delete_profile(user_id: int):
    """Delete a traveler's profile."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        DELETE FROM traveler_profiles
        WHERE user_id = ?
        """,
        (user_id,),
    )

    connection.commit()
    connection.close()

    return True


if __name__ == "__main__":

    from database import initialize_database

    initialize_database()

    print("Testing Traveler Profile...")
    print("-" * 40)

    # Test user ID created by auth.py
    test_user_id = 1

    save_profile(
        user_id=test_user_id,
        full_name="Test Traveler",
        age=22,
        location="Layyah",
        travel_style="Adventure",
        interests="Nature, Food, Photography",
        preferred_budget=80000,
    )

    profile = get_profile(test_user_id)

    if profile:
        print("Profile saved successfully!")
        print()
        print("Name:", profile["full_name"])
        print("Age:", profile["age"])
        print("Location:", profile["location"])
        print("Travel Style:", profile["travel_style"])
        print("Interests:", profile["interests"])
        print("Preferred Budget:", profile["preferred_budget"])
    else:
        print("Profile was not found.")