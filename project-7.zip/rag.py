from pathlib import Path

from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CHROMA_DIR = BASE_DIR / "chroma_db"


def load_documents():
    documents = []

    for file_path in DATA_DIR.glob("*.txt"):
        text = file_path.read_text(encoding="utf-8")

        documents.append(
            Document(
                page_content=text,
                metadata={
                    "source": file_path.name
                },
            )
        )

    return documents


def create_vector_store():
    documents = load_documents()

    if not documents:
        raise ValueError("No documents found inside the data folder.")

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vector_store = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        persist_directory=str(CHROMA_DIR),
        collection_name="travelmate_knowledge",
    )

    return vector_store


def search_knowledge(query: str, k: int = 3):
    vector_store = create_vector_store()

    results = vector_store.similarity_search(
        query,
        k=k,
    )

    return results


if __name__ == "__main__":
    print("Building TravelMate Knowledge Base...")
    print("-" * 40)

    try:
        results = search_knowledge(
            "What places can I visit in Islamabad?"
        )

        print("\nRelevant Information:\n")

        for result in results:
            print("Source:", result.metadata["source"])
            print(result.page_content[:500])
            print("-" * 40)

    except Exception as error:
        print("Error:")
        print(error)