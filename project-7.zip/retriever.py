from rag import create_vector_store


def get_travel_information(question: str) -> str:
    """
    Search the TravelMate knowledge base
    and return relevant travel information.
    """

    vector_store = create_vector_store()

    results = vector_store.similarity_search(
        question,
        k=3
    )

    if not results:
        return "No relevant information was found."

    information = []

    for result in results:
        source = result.metadata.get(
            "source",
            "Unknown"
        )

        information.append(
            f"Source: {source}\n"
            f"{result.page_content}"
        )

    return "\n\n---\n\n".join(information)


if __name__ == "__main__":

    question = input(
        "Ask TravelMate a travel question: "
    )

    try:
        answer = get_travel_information(question)

        print("\nRelevant Travel Information:")
        print("-" * 40)
        print(answer)

    except Exception as error:
        print("\nError:")
        print(error)