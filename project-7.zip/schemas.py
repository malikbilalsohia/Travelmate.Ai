from typing import List
from pydantic import BaseModel, Field


class TravelerProfile(BaseModel):
    """Information provided by the traveler."""

    destination: str = Field(description="Trip destination")
    starting_location: str = Field(description="Starting location")
    days: int = Field(ge=1, le=30, description="Number of travel days")
    budget: float = Field(gt=0, description="Total trip budget")
    travelers: int = Field(ge=1, le=50, description="Number of travelers")
    interests: List[str] = Field(
        default_factory=list,
        description="Traveler interests such as food, nature, sightseeing"
    )


class BudgetPlan(BaseModel):
    """Estimated budget breakdown."""

    transport: float
    accommodation: float
    food: float
    activities: float
    extra: float
    total: float


class DailyPlan(BaseModel):
    """Plan for one day of the trip."""

    day: int
    morning: str
    afternoon: str
    evening: str


class TravelPlan(BaseModel):
    """Complete final TravelMate plan."""

    destination: str
    duration_days: int
    total_budget: float
    budget_plan: BudgetPlan
    itinerary: List[DailyPlan]
    packing_list: List[str]
    travel_tips: List[str]