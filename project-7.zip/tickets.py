"""API-free Pakistan domestic flight-ticket demo for TravelMate AI."""

from __future__ import annotations

from datetime import date, timedelta

import streamlit as st


PAKISTAN_CITIES = {
    "Lahore (LHE)": "LHE",
    "Islamabad (ISB)": "ISB",
    "Karachi (KHI)": "KHI",
    "Peshawar (PEW)": "PEW",
    "Quetta (UET)": "UET",
    "Multan (MUX)": "MUX",
    "Faisalabad (LYP)": "LYP",
    "Skardu (KDU)": "KDU",
    "Gilgit (GIL)": "GIL",
    "Muzaffarabad (MFG)": "MFG",
}

DEMO_AIRLINES = (
    ("PIA", "PK"),
    ("Airblue", "PA"),
    ("Serene Air", "ER"),
)


def get_demo_flights(origin: str, destination: str, travelers: int, round_trip: bool) -> list[dict]:
    """Return clearly labelled sample fares without using an external API."""
    city_names = list(PAKISTAN_CITIES)
    distance_factor = abs(city_names.index(origin) - city_names.index(destination))
    base_fare = 10500 + distance_factor * 1750

    if "Skardu" in destination or "Gilgit" in destination:
        base_fare += 6500
    if "Karachi" in origin or "Karachi" in destination:
        base_fare += 2500

    journey_factor = 1.82 if round_trip else 1.0
    total_for_all = base_fare * journey_factor * travelers
    schedules = (
        ("06:20", "08:05", "1h 45m"),
        ("11:10", "13:00", "1h 50m"),
        ("18:40", "20:35", "1h 55m"),
    )

    flights = []
    for index, (airline, code) in enumerate(DEMO_AIRLINES):
        departure, arrival, duration = schedules[index]
        fare = total_for_all * (1 + index * 0.09)
        flights.append(
            {
                "airline": airline,
                "flight_number": f"{code}-{240 + distance_factor * 3 + index}",
                "departure": departure,
                "arrival": arrival,
                "duration": duration,
                "stops": "Non-stop",
                "fare": fare,
                "baggage": "20 kg checked + 7 kg cabin",
            }
        )
    return flights


def _apply_ticket_styles() -> None:
    st.markdown(
        """
        <style>
        .ticket-page-title, .ticket-page-title * { color: #ffffff !important; }
        .ticket-note, .ticket-note * { color: #e4eef7 !important; }
        .ticket-card { background: linear-gradient(145deg, #163a5f, #0d2340) !important; border: 1px solid #7da4c3 !important; border-radius: 18px !important; padding: 1.25rem !important; margin: .75rem 0 !important; box-shadow: 0 12px 26px rgba(0,0,0,.25) !important; }
        .ticket-airline { color: #ffffff !important; font-size: 1.22rem !important; font-weight: 850 !important; }
        .ticket-meta { color: #dcebf7 !important; font-size: .9rem !important; }
        .ticket-time { color: #ffffff !important; font-size: 1.35rem !important; font-weight: 900 !important; }
        .ticket-route { color: #bce8ff !important; font-size: .9rem !important; }
        .ticket-fare { color: #ffffff !important; font-size: 1.45rem !important; font-weight: 900 !important; }
        .ticket-panel { background: #0d213b !important; border: 1px solid #7da4c3 !important; border-left: 5px solid #4fc3ff !important; border-radius: 16px !important; padding: 1.3rem !important; }
        .ticket-panel, .ticket-panel * { color: #ffffff !important; }
        .stForm, [data-testid="stForm"] { background: #0d213b !important; border: 1px solid #6f94b3 !important; border-radius: 18px !important; }
        .stTextInput input, .stNumberInput input, input { color: #ffffff !important; -webkit-text-fill-color: #ffffff !important; background: #102541 !important; border: 1px solid #8cafc8 !important; }
        .stTextInput input::placeholder, .stNumberInput input::placeholder { color: #c9dbea !important; opacity: 1 !important; }
        .stButton > button, .stFormSubmitButton > button { color: #061526 !important; -webkit-text-fill-color: #061526 !important; background: linear-gradient(90deg, #87ddff, #45bfff) !important; border: none !important; border-radius: 12px !important; font-weight: 850 !important; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_ticket_page() -> None:
    """Render the complete domestic ticket search and demo booking page."""
    _apply_ticket_styles()
    st.markdown('<div class="ticket-page-title"><h1>🎟️ Pakistan Flight Tickets</h1></div>', unsafe_allow_html=True)
    st.markdown('<p class="ticket-note">Compare sample domestic flights in a professional airline-style interface.</p>', unsafe_allow_html=True)
    st.info("Demo mode: fares are illustrative sample prices. No live API, payment, or real ticket is issued.")

    city_options = list(PAKISTAN_CITIES)
    with st.form("ticket_search_form"):
        first_row = st.columns(2)
        with first_row[0]:
            origin = st.selectbox("🛫 From", city_options, index=0)
        with first_row[1]:
            destination = st.selectbox("🛬 To", city_options, index=1)

        second_row = st.columns(3)
        with second_row[0]:
            departure = st.date_input("📅 Departure", value=date.today() + timedelta(days=1), min_value=date.today())
        with second_row[1]:
            return_date = st.date_input("📅 Return", value=date.today() + timedelta(days=4), min_value=date.today())
        with second_row[2]:
            travelers = st.number_input("👥 Travelers", min_value=1, max_value=9, value=1, step=1)

        trip_type = st.radio("Trip type", ("One way", "Round trip"), horizontal=True)
        submitted = st.form_submit_button("🔎 Search Sample Flights", type="primary", use_container_width=True)

    if submitted:
        if origin == destination:
            st.error("Please select two different cities.")
        elif trip_type == "Round trip" and return_date < departure:
            st.error("Return date must be after the departure date.")
        else:
            st.session_state.ticket_search = {
                "origin": origin,
                "destination": destination,
                "departure": departure.isoformat(),
                "return_date": return_date.isoformat(),
                "travelers": int(travelers),
                "round_trip": trip_type == "Round trip",
            }
            st.session_state.selected_ticket = None
            st.rerun()

    search = st.session_state.get("ticket_search")
    if not search:
        st.markdown('<div class="ticket-panel"><p><strong>How it works</strong></p><p>Choose two Pakistani cities, select your dates, and compare three sample airline options.</p></div>', unsafe_allow_html=True)
        return

    flights = get_demo_flights(search["origin"], search["destination"], search["travelers"], search["round_trip"])
    route_type = "Round trip" if search["round_trip"] else "One way"
    st.markdown(f"## {search['origin']} → {search['destination']}")
    st.markdown(
        f'<p class="ticket-note">{search["departure"]} · {route_type} · {search["travelers"]} traveler(s) · {len(flights)} sample flights found</p>',
        unsafe_allow_html=True,
    )

    origin_code = PAKISTAN_CITIES[search["origin"]]
    destination_code = PAKISTAN_CITIES[search["destination"]]
    for index, flight in enumerate(flights):
        st.markdown(
            f"""
            <div class="ticket-card">
                <div class="ticket-airline">{flight['airline']} <span class="ticket-meta">{flight['flight_number']}</span></div>
                <div class="ticket-meta" style="margin-top:.45rem;">{flight['baggage']} · {flight['stops']}</div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem;">
                    <div><div class="ticket-time">{flight['departure']} — {flight['arrival']}</div><div class="ticket-route">{origin_code} → {destination_code} · {flight['duration']}</div></div>
                    <div style="text-align:right;"><div class="ticket-fare">Rs. {flight['fare']:,.0f}</div><div class="ticket-meta">total for {search['travelers']} traveler(s)</div></div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        if st.button("Select Flight", key=f"ticket_select_{index}", use_container_width=True):
            selected = dict(flight)
            selected.update(search)
            st.session_state.selected_ticket = selected
            st.rerun()

    selected_ticket = st.session_state.get("selected_ticket")
    if selected_ticket:
        st.divider()
        st.markdown("## ✅ Demo Booking Confirmation")
        st.markdown(
            f'<div class="ticket-panel"><p><strong>{selected_ticket["airline"]} {selected_ticket["flight_number"]}</strong></p><p>{selected_ticket["origin"]} → {selected_ticket["destination"]} · {selected_ticket["departure"]}</p><p><strong>Total: Rs. {selected_ticket["fare"]:,.0f}</strong></p></div>',
            unsafe_allow_html=True,
        )
        with st.form("demo_booking_form"):
            passenger = st.text_input("Passenger name", placeholder="Enter passenger name")
            email = st.text_input("Email for demo confirmation", placeholder="name@example.com")
            confirm = st.form_submit_button("🎫 Confirm Demo Booking", type="primary", use_container_width=True)
        if confirm:
            if not passenger.strip() or not email.strip():
                st.warning("Please enter passenger name and email.")
            else:
                reference = f"TM-{selected_ticket['flight_number'].replace('-', '')}-{selected_ticket['travelers']}"
                st.success(f"Demo booking confirmed. Reference: {reference}. No payment was processed.")
