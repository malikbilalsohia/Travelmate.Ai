from langchain_core.tools import tool


@tool
def calculate_budget(
    total_budget: float,
    transport_percent: float = 25,
    accommodation_percent: float = 30,
    food_percent: float = 20,
    activities_percent: float = 15,
) -> str:
    """
    Divide the travel budget into transport, accommodation, food,
    activities, and extra expenses.
    """

    used_percent = (
        transport_percent
        + accommodation_percent
        + food_percent
        + activities_percent
    )

    if used_percent > 100:
        return "Error: Budget percentages cannot be greater than 100%."

    transport = total_budget * transport_percent / 100
    accommodation = total_budget * accommodation_percent / 100
    food = total_budget * food_percent / 100
    activities = total_budget * activities_percent / 100
    extra = total_budget - (
        transport + accommodation + food + activities
    )

    return f"""
Budget Breakdown:

Transport: Rs. {transport:,.0f}
Accommodation: Rs. {accommodation:,.0f}
Food: Rs. {food:,.0f}
Activities: Rs. {activities:,.0f}
Extra/Emergency: Rs. {extra:,.0f}

Total Budget: Rs. {total_budget:,.0f}
"""


@tool
def calculate_available_time(days: int, hours_per_day: float) -> str:
    """
    Calculate the total available time for a trip.
    """

    if days <= 0 or hours_per_day <= 0:
        return "Error: Days and hours per day must be greater than zero."

    total_hours = days * hours_per_day

    return (
        f"Trip Duration: {days} days\n"
        f"Available hours per day: {hours_per_day}\n"
        f"Total available hours: {total_hours:g}"
    )


@tool
def generate_packing_list(
    trip_type: str,
    days: int,
) -> str:
    """
    Generate a basic packing checklist based on trip type and duration.
    """

    if days <= 0:
        return "Error: Trip duration must be greater than zero."

    packing_items = [
        "Clothes",
        "Comfortable shoes",
        "Mobile phone",
        "Phone charger",
        "Power bank",
        "Personal identification documents",
        "Basic personal items",
    ]

    trip_type = trip_type.lower()

    if "mountain" in trip_type or "hiking" in trip_type:
        packing_items.extend(
            [
                "Warm clothing",
                "Water bottle",
                "Small backpack",
            ]
        )

    if "family" in trip_type:
        packing_items.append("Family-required personal items")

    packing_items.append(f"Clothes suitable for approximately {days} days")

    return "Packing Checklist:\n" + "\n".join(
        f"- {item}" for item in packing_items
    )