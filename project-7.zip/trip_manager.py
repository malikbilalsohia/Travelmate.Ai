from database import get_connection


def save_trip(
    user_id: int,
    destination: str,
    starting_location: str,
    days: int,
    budget: float,
    travelers: int,
    interests: str,
    trip_plan: str,
):
    """Save an AI-generated trip for a user."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        INSERT INTO trips
        (
            user_id,
            destination,
            starting_location,
            days,
            budget,
            travelers,
            interests,
            trip_plan
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user_id,
            destination,
            starting_location,
            days,
            budget,
            travelers,
            interests,
            trip_plan,
        ),
    )

    connection.commit()

    trip_id = cursor.lastrowid

    connection.close()

    return trip_id


def get_user_trips(user_id: int):
    """Return all trips belonging to a user."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM trips
        WHERE user_id = ?
        ORDER BY created_at DESC
        """,
        (user_id,),
    )

    trips = cursor.fetchall()

    connection.close()

    return [dict(trip) for trip in trips]


def get_trip(trip_id: int, user_id: int):
    """Get one specific trip belonging to the user."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM trips
        WHERE id = ?
        AND user_id = ?
        """,
        (trip_id, user_id),
    )

    trip = cursor.fetchone()

    connection.close()

    if trip is None:
        return None

    return dict(trip)


def delete_trip(trip_id: int, user_id: int):
    """Delete a saved trip."""

    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        DELETE FROM trips
        WHERE id = ?
        AND user_id = ?
        """,
        (trip_id, user_id),
    )

    connection.commit()

    deleted = cursor.rowcount > 0

    connection.close()

    return deleted


if __name__ == "__main__":

    from database import initialize_database

    initialize_database()

    print("Testing TravelMate Trip Manager...")
    print("-" * 40)

    test_trip_id = save_trip(
        user_id=1,
        destination="Islamabad",
        starting_location="Lahore",
        days=3,
        budget=50000,
        travelers=4,
        interests="Nature, Food, Photography",
        trip_plan="3-day Islamabad family travel plan.",
    )

    print("Trip saved successfully!")
    print("Trip ID:", test_trip_id)

    trips = get_user_trips(1)

    print()
    print("Saved Trips:")

    for trip in trips:
        print(
            f"- {trip['destination']} | "
            f"{trip['days']} days | "
            f"Rs. {trip['budget']:,.0f}"
        )